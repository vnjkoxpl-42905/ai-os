# LSAT U dashboard review files

Open student-dashboard.html or teacher-dashboard.html directly in a browser. No server or login is needed. Upload the matching HTML, handoff Markdown and screenshot (if present) to another model. HTML preserves the interactive design; Markdown gives the review instructions; PNG provides an immediate visual for models that cannot render HTML.

These exports contain only typed fictional fixtures, not real student account data. They render production Home components but do not include the authenticated sidebar, other pages, backend persistence or the full question bank. State and Theme controls exercise the available sample states. Navigation logs its destination; it does not launch a drill or send an assignment.

Regenerate from the repository:

```powershell
node scripts/verification/export-role-home.mjs --out "C:/Users/Joshu/Downloads/LSAT-U-Dashboard-Handoff-2026-10-22"
```

The script replaces only its named generated files and preserves unrelated files. Fonts are cached after the first run; subsequent runs work without font downloads. No source components or backend records are modified. Source revision: 6a167c8555b4a404334310aad48a5d748b1b0861, uncommitted work included: true. Automatic checks are in auto-checks.json. Browser/reviewer findings, when supplied separately, are in REVIEW.md.
